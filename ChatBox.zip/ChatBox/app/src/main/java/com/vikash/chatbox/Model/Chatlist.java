package com.vikash.chatbox.Model;

public class Chatlist {
    public String id;

    public Chatlist(String id) {
        this.id=id;
    }

    public Chatlist(){

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
