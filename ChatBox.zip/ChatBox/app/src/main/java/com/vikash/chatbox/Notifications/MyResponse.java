package com.vikash.chatbox.Notifications;

public class MyResponse {

    public int success;
}
